package com.company;

public class Main {

    public static void main(String[] args) {
        int a = 5;
        int b = 11;
        int c;
        c = a;
        a = b;
        b = c;
        System.out.println(a);
        System.out.println(b);
    }
}
