package com.company;

public class Dog {
    public static void main(String[]args){
        String dogName = "Oliver,";
        String owner = "Alex";
        String breed = "Finnish Sptz,";
        byte ageOwner = 17;
        byte ageDog = 2;
        String sex = "male";
        String color = "white";
        System.out.println("Куче:" + dogName + breed + color);
        System.out.println("Собственост на:"+owner);
        byte pupies = 5;
        System.out.println("Има" +pupies +"деца");
        String puppy1 = "Pesho";
        String puppy2 = "Ivan";
        String puppy3 = "Petar";
        String puppy4 = "Maria";
        String puppy5 = "Gergana";

    }
}
